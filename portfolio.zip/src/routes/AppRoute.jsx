import React from 'react'
import { createBrowserRouter, RouterProvider } from 'react-router'
import Hero from '../pages/hero/ui/page/Hero'
import Project from '../pages/work/ui/page/Project'
import About from '../pages/about/ui/page/About'
import Skill from '../pages/skills/ui/page/Skill'
import Experience from '../pages/experience/ui/page/Experience'
import Education from '../pages/education/ui/page/Education'
import Contact from '../pages/contact/ui/page/Contact'
import MainLayout from '../layout/MainLayout'

const AppRoute = () => {

    const router = createBrowserRouter([
        {
            path: '/',
            element: <MainLayout />,
            children: [
                {
                    path: '',
                    element: <Hero />
                },
                {
                    path: '/project',
                    element: <Project />
                },
                {
                    path: 'about',
                    element: <About />
                },
                {
                    path: 'skill',
                    element: <Skill />
                },
                {
                    path: 'experience',
                    element: <Experience />
                },
                {
                    path: 'education',
                    element: <Education />
                },
                {
                    path: 'contact',
                    element: <Contact />
                }
            ]
        }
    ])

    return <RouterProvider router={router} />
}

export default AppRoute