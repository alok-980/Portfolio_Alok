import React from 'react'
import Loader from '../sheared/ui/page/Loader'
import Navbar from '../sheared/ui/page/Navbar'
import Footer from '../sheared/ui/page/Footer'
import { Outlet } from 'react-router'

const MainLayout = () => {
  return (
    <div>
      <Loader />
      <Navbar />
      <Outlet />
      <Footer />
    </div>
  )
}

export default MainLayout